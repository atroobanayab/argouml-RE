# argouml
Main project of argouml.

Started in January 1998. Converted from CVS to Subversion in 2006. Converted to git in 2019.

## Resources

* Github organisation: <https://github.com/argouml-tigris-org>
* Web page with maven sites: <https://argouml-tigris-org.github.io/>

## Contributing

Short summary on how to contribute to the project using github and gerrithub:

* Push changes towards master to gerrithub.
* One change per issue.
* Code clean-up in separate changes (gerrithub will make each commit into a change).
* Use the repo tool.

A longer explaination is in <https://github.com/argouml-tigris-org/argouml/wiki/Working-in-the-project>
